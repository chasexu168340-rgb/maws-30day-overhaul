param(
  [string]$Root = "E:\TH比赛照片",
  [string]$Staging = "staging/reforge-unlocks-v1"
)

Set-Location $Root

git switch $Staging
git pull --ff-only

$branches = @(
  "feat/reforge-core-unlocks",
  "feat/reforge-ui-locks",
  "feat/reforge-metro-content",
  "feat/reforge-skill-unlocks",
  "feat/reforge-early-combat",
  "qa/reforge-unlocks-v1"
)

foreach ($branch in $branches) {
  Write-Host "Merging $branch"
  git merge --no-ff $branch
  if ($LASTEXITCODE -ne 0) { throw "Merge failed: $branch" }
  npm run build
  if ($LASTEXITCODE -ne 0) { throw "Build failed after merging: $branch" }
}

git diff --check
