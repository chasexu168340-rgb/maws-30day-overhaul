param(
  [string]$BaseBranch = "staging/reforge-unlocks-v1",
  [string]$Root = "E:\TH比赛照片"
)

Set-Location $Root

git worktree add ..\maws-agent-01-core -b feat/reforge-core-unlocks $BaseBranch
git worktree add ..\maws-agent-02-ui -b feat/reforge-ui-locks $BaseBranch
git worktree add ..\maws-agent-03-metro -b feat/reforge-metro-content $BaseBranch
git worktree add ..\maws-agent-04-skills -b feat/reforge-skill-unlocks $BaseBranch
git worktree add ..\maws-agent-05-combat -b feat/reforge-early-combat $BaseBranch
git worktree add ..\maws-agent-06-qa -b qa/reforge-unlocks-v1 $BaseBranch
