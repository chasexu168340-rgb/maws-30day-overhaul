# 《了不起的武术模拟器》重铸优化计划：多 Agent / 多窗口开发书 v0.3

目标仓库：`chasexu168340-rgb/maws-30day-overhaul`  
当前主角：陆小闲  
当前阶段：已具备 Phaser + DOM 的 30 天 Web MVP 骨架，开始进入“重铸优化计划”。

---

## 0. 当前项目实读结论

当前项目不是空仓，也不是单纯策划案。它已经有可运行架构：入口是 `maws_30day_overhaul_v3.html`，源码在 `maws_src/`，资源在 `assets/`。Phaser 负责背景、角色 sprite、动画、伤害数字和战斗特效；DOM 负责主线/待办、装备栏、训练小游戏、战斗 HUD、技能卡、队列、日志和弹窗。

当前协作规则也已经明确：不要默认重构项目，不要顺手改玩法、数值、资产结构或存档结构；当前项目真实架构是 DOM + Phaser 混合架构，数据在 `content/data.js`，状态在 `simulation/state.js`，战斗在 `simulation/combat.js`，DOM UI 在 `dom/ui.js` / `dom/ui.css`，资源 manifest 在 `assets/manifest.js`。

这次重铸优化计划不是“从零做系统”，而是在已有 `MAW_RULES / FATHER_DIARY / MAW_FORMS / maw state / 训练小游戏 / 地点 / 战斗短窗口` 之上，继续把成长节奏和多 Agent 工作流收束起来。

当前代码已经开始接入重铸系统：`data.js` 里已经有 `MAW_RULES`、`FATHER_DIARY`、`MAW_FORMS`，并且已经加入散打、空手道、跆拳道等风格和地点。`state.js` 里也已经有 `createDefaultMaw()`、`applyMawPatch()`、`convertMisreadToFatherMemory()`、`applyMainlineMawEffects()`、`MAW_MODULE_GUIDE` 和 `FINAL_OBJECTIVES`。

当前最明显的下一步问题有三个：

1. 地铁目前只是 `TRAVEL_TUNING.metro` 出行方式，还不是一个可进入地点。
2. 新开局仍然一次性解锁了太多技能，包括 `jab / straight / guard / dodge / advance / retreat / dirtyescape / talkdown / mystic`，养成感不足。
3. 散打馆、空手道道场、跆拳道社已经进了 `LOCS`，但前期不应该全部开放，需要地点锁、事件解锁和技能解锁节奏。

---

## 1. 制作目标

重铸优化计划的核心目标：

> 让陆小闲从“手里只有几招旧拳谱和嘴硬”的状态开始，在 30 天里通过地点逐步开放、NPC 指点、训练小游戏、事件和战斗复盘，一步一步把真实技术写回茂家拳谱。

这轮不追求新增很多系统，而是把已有系统改成更强的成长节奏。

玩家前期应该有明显限制：地点少、技能少、钱少、认知错。  
玩家中期应该开始扩展：拳馆、武馆、MMA、地铁站事件、身体训练逐步打开。  
玩家后期才接触散打、空手道、跆拳道这些更进阶的“百家入茂”内容。

新的核心体验：

> 玩家不是一开始就有完整技能栏，而是每开一个地点，就多理解一种真实东西；每获得一个技能，茂家拳谱就多一条新注。

---

## 2. 推荐的新地图开放节奏

### 2.1 地点分层

| 层级 | 地点 | 开放状态 | 设计目的 |
|---|---|---|---|
| 起始层 | 出租屋 `home` | Day 1 默认开放 | 父亲、拳谱、复盘、休息 |
| 起始层 | 便利店 `store` | Day 1 默认开放 | 补给、打工、小满、生活压力 |
| 起始层 | 地铁站 `metro_station` | Day 1 默认开放 | 城市枢纽、误判胜利、短视频信息流、地点解锁入口 |
| 低风险层 | 公园 `park` | Day 2 或 Day 3 解锁 | 低风险验货、推手大爷、观察 |
| 赚钱层 | 工地 `worksite` | Day 4 或现金低事件解锁 | 赚钱和体能沉淀，但疲劳高 |
| 真训练层 | 拳馆 `boxing` | Day 9 日记后解锁 | 刺拳、直拳、抱架，开山拳重铸 |
| 恢复层 | 理疗店 `physio` | Day 9 后解锁 | 身体会记账，恢复和伤病管理 |
| 身体层 | 社区健身房 `gym` | Day 10 或拳馆介绍解锁 | 身体底子，铁布衫重铸 |
| 传统层 | 武馆 `wuguan` | Day 13 或周青山线索解锁 | 掌根短击、破平衡、传统拆解 |
| 地面层 | MMA 馆 `mma` | Day 16 或被摔事件后解锁 | 防摔、脱身、落地根重铸 |
| 风险层 | 旧城区 `street` | Day 18 后解锁 | 热度、街头判断、非战斗胜利 |
| 进阶层 | 散打馆 `sanda_gym` | Day 20 或茂拳完成度 20 解锁 | 拳腿摔组合，百家入茂扩展 |
| 进阶层 | 空手道道场 `karate_dojo` | Day 22 或茂拳完成度 30 解锁 | 直线爆发和收招纪律 |
| 进阶层 | 跆拳道社 `taekwondo_club` | Day 24 或茂拳完成度 40 解锁 | 腿法、距离反击和落地稳定 |

### 2.2 新增地点：地铁站 `metro_station`

地铁站不是简单交通按钮，而是早期最重要的城市过渡场景。

它承担四个功能：

1. 城市枢纽：解释为什么其他地点还没开放。
2. 信息流入口：短视频、打假视频、评论区、阿豹初见。
3. 误判胜利：Day 2 地铁见义勇为，陆小闲第一次把威慑成功误解成茂家拳显灵。
4. 后续地点解锁：玩家在地铁站听说拳馆、武馆、MMA 馆、散打馆等地点。

推荐新增地点数据：

```js
metro_station: {
  name: '地铁站',
  icon: '铁',
  open: [360, 1440],
  desc: '城市把人吞进去，再准点吐出来。这里有通勤、短视频、误会和下一站的线索。'
}
```

推荐新增行动：

```js
ACTIONS.metro_station = [
  {
    id: 'metro_observe',
    name: '观察通勤人流',
    icon: '看',
    time: 35,
    sp: 0,
    desc: '看距离、看动线、看冲突怎么在拥挤里发酵。',
    type: 'simple',
    gain: { jud: 1, street: 4, calm: 2 }
  },
  {
    id: 'metro_short_video',
    name: '刷打假短视频',
    icon: '刷',
    time: 30,
    sp: 2,
    desc: '越刷越上头，越刷越想证明点什么。',
    type: 'simple',
    gain: { heat: 1, auth: -1, misread: 3 }
  },
  {
    id: 'metro_commute_shadow',
    name: '站台步法小练',
    icon: '步',
    time: 25,
    sp: 6,
    desc: '不占人、不丢人，练一步进退。',
    type: 'simple',
    gain: { skill: 'retreat', xp: 4, jud: 1, fatigue: 3 }
  }
];
```

注意：`misread` 当前不是普通 gain 字段，需要 Agent 在 `applyGain()` 或 `applyMawPatch()` 的接入处处理。也可以先通过 `maw` 字段接入，不强行塞进经济层。

---

## 3. 推荐的新技能开放节奏

### 3.1 当前问题

目前新开局在 `createNewState()` 中一次性解锁了：

```js
jab, straight, guard, dodge, advance, retreat, dirtyescape, talkdown, mystic
```

这会导致两个问题：

1. 陆小闲一开始不像“强人设弱实力”的角色。
2. 拳馆、MMA、武馆等地点的技能教学价值被削弱。

### 3.2 新开局建议

新开局只保留 4 个技能：

```js
unlocked: {
  mystic: 1,
  guard: 1,
  retreat: 1,
  talkdown: 1
},

equipSkills: ['mystic', 'guard', 'retreat', 'talkdown', null, null]
```

解释：

- `mystic` 是茂家拳旧招，代表中二但不稳定的旧拳谱。
- `guard` 是本能抱头，不代表专业防守。
- `retreat` 是保命动作。
- `talkdown` 是街头降温，符合现实题材。

前期不要给 `jab` 和 `straight`。玩家必须在拳馆或 Day 8 后才真正学到拳击基础。

### 3.3 技能解锁路线

| 技能 | 推荐解锁地点/事件 | 叙事含义 |
|---|---|---|
| `dodge` | 公园观察 / 站台步法小练 | 不只是躲，是让脚和脑子一起动 |
| `jab` | Day 9 后拳馆入门 | 第一次知道“拳可以先探路” |
| `straight` | 梁教练纠错 / 沙包连击 | 开山拳新注核心 |
| `palm` | 武馆压力测试 | 传统动作落地为短打 |
| `offbalance` | 周青山拆招 | 传统拆解模块核心 |
| `sprawl` | MMA 防摔判断课 | 现代地面系统开启 |
| `escape` | MMA 地面脱身课 | 不被地面无限教育 |
| `dirtyescape` | 旧城区 / 地铁风险事件 | 街头判断模块核心 |
| `advance` | MMA / 散打 | 真正理解进身的代价 |
| `lowkick` | 散打馆 | 腿法进入实战模块 |
| `frontkick` | 空手道或跆拳道 | 中远距离拒门 |
| `grip` / `takedown` | MMA 或散打馆 | 拳摔转换 |
| `sanda_*` | 散打馆 | 百家入茂进阶 |
| `karate_*` | 空手道道场 | 收招纪律 |
| `tkd_*` | 跆拳道社 | 腿法节奏和落地稳定 |

### 3.4 技能解锁弹窗

每次新技能解锁都应该有独立弹窗，而不是只在结算里加一行。

示例：

```text
学会：刺拳

梁教练把你的手推回下巴前。
“别急着开山。先学会敲门。”

茂家开山拳新注进度 +8%
```

---

## 4. 技术接入方案

### 4.1 新增 `LOCATION_UNLOCKS`

建议放在 `maws_src/content/data.js`：

```js
export const LOCATION_UNLOCKS = {
  home: { default: true },
  store: { default: true },
  metro_station: { default: true },
  park: { flag: 'unlock_park', day: 3, reason: '先在地铁站和便利店把城市摸清楚。' },
  worksite: { flag: 'unlock_worksite', day: 4, reason: '刘胖子还没把日结活转给你。' },
  boxing: { flag: 'unlock_boxing', day: 9, reason: '真正被一阵风打醒后，你才愿意听拳馆的真话。' },
  physio: { flag: 'unlock_physio', day: 9, reason: '身体还没开始正式投诉。' },
  gym: { flag: 'unlock_gym', day: 10, reason: '先确认身体到底差在哪里。' },
  wuguan: { flag: 'unlock_wuguan', day: 13, reason: '传统拆解还没到时候。' },
  mma: { flag: 'unlock_mma', day: 16, reason: '地面课不是第一天就能理解的东西。' },
  street: { flag: 'unlock_street', day: 18, reason: '旧城区的风险还没把你点名。' },
  sanda_gym: { flag: 'unlock_sanda_gym', minReforge: 20, day: 20, reason: '拳腿摔组合需要一点基础。' },
  karate_dojo: { flag: 'unlock_karate_dojo', minReforge: 30, day: 22, reason: '先把直线和回收练明白。' },
  taekwondo_club: { flag: 'unlock_taekwondo_club', minReforge: 40, day: 24, reason: '腿法漂亮之前，先学会落地。' }
};
```

### 4.2 新增 `INITIAL_SKILLS` 与 `SKILL_UNLOCKS`

```js
export const INITIAL_SKILLS = ['mystic', 'guard', 'retreat', 'talkdown'];

export const SKILL_UNLOCKS = {
  dodge: { loc: 'park', action: 'observe_park', reason: '你终于意识到，脚要先动。' },
  jab: { loc: 'boxing', action: 'bag', reason: '梁教练说：先敲门，别开山。' },
  straight: { loc: 'boxing', action: 'heavybag', reason: '开山拳第一次有了回收。' },
  palm: { loc: 'wuguan', action: 'pressure_test', reason: '封喉手被拆成了掌根短击。' },
  offbalance: { loc: 'wuguan', action: 'push_train', reason: '你开始理解重心不是玄学。' },
  sprawl: { loc: 'mma', action: 'sprawl_drill', reason: '你第一次没有被地板完整收下。' },
  escape: { loc: 'mma', action: 'ground_escape', reason: '从地上起来，也是本事。' },
  dirtyescape: { loc: 'street', action: 'oldtown_watch', reason: '最像高手的一步，是让事情别升级。' }
};
```

### 4.3 `state.js` 必要函数

新增或补强：

```js
function isLocationUnlocked(state, locId) {}
function locationLockReason(state, locId) {}
function unlockLocation(state, locId, source = '') {}
function unlockSkill(state, skillId, source = '') {}
function applyUnlocks(state, sourceObject) {}
```

接入点：

- `createNewState()`：只给 `INITIAL_SKILLS`。
- `migrateSave()`：旧存档不要强行删玩家已有技能；只给新存档走新节奏。
- `buildRenderModel()`：给每个 loc 增加 `locked` / `lockReason`，给每个 skill 增加 `lockedReason` / `unlockHint`。
- `openTravel` / `travel`：锁定地点不可前往，toast 显示原因。
- `doAction` / `finishTrainingMini` / `resolveStoryChoice` / `postReview`：都可以调用 `applyUnlocks()`。

### 4.4 UI 必要表现

地图地点卡：

```text
拳馆
未开放
真正被一阵风打醒后，你才愿意听拳馆的真话。
```

技能卡：

```text
直拳
未学会
来源：拳馆 · 重靶爆点 / 梁教练纠错
```

解锁弹窗：

```text
地点开放：拳馆

你终于愿意听一个真正会打的人说话了。
```

### 4.5 机会卡限制

`events.js` 生成机会卡时应该过滤未开放地点，或者显示为“听说”但不能直接跳转。

最稳方案：在 `buildOpportunities(state)` 过滤：

```js
.filter(rule => !rule.loc || isLocationUnlocked(state, rule.loc))
```

但 `events.js` 目前没有引用 state helper，容易形成循环依赖。更稳的做法是：

- `events.js` 仍生成机会卡。
- `state.js` 的 `takeOpportunity` 判断地点是否解锁。
- `ui.js` 对 locked opportunity 显示“线索未成熟”。

---

## 5. 多 Agent / 多窗口工作流总原则

这次最重要的不是让所有人同时乱改，而是让每个人只碰自己的边界。

### 5.1 核心规则

1. 所有人从同一个 `staging/reforge-unlocks-v1` 分支开 worktree。
2. 每个 Agent 用自己的 branch 和 worktree。
3. 不允许两个 Agent 同时直接修改 `data.js` 和 `state.js`。
4. 内容创作型 Agent 优先写 `docs/content_proposals/*.md`，不要直接改代码。
5. 只有 Integrator 负责合并、解决冲突、更新 `docs/TASK_PLAN.md`。
6. 普通 Agent 为避免冲突，写 `docs/agent_reports/<agent>.md`，不要修改 `docs/TASK_PLAN.md`。
7. 每个 Agent 最后必须运行 `npm run build`，除非它完全没改运行代码。

### 5.2 文件所有权表

| Agent | 角色 | 允许修改 | 禁止修改 |
|---|---|---|---|
| Agent 00 | 整合负责人 | `docs/TASK_PLAN.md`、合并所有分支 | 不直接大改玩法 |
| Agent 01 | 地点锁与初始技能核心 | `data.js`、`state.js` | `ui.css`、combat 公式、资产文件 |
| Agent 02 | 地图/技能 UI 表现 | `ui.js`、`ui.css` | `data.js`、`state.js` |
| Agent 03 | 地铁站内容 | `docs/content_proposals/metro_station.md`，代码阶段再改 `data.js/events.js` | `state.js`、`combat.js` |
| Agent 04 | 技能解锁链 | `docs/content_proposals/skill_unlocks.md`，代码阶段再改 `data.js/state.js` | UI 和资源 |
| Agent 05 | 早期战斗乐趣 | `combat.js`，必要时少量 `state.js` | 地图、资产、经济曲线 |
| Agent 06 | QA 回归 | `docs/agent_reports/qa.md` | 运行代码 |
| Friend Agent | 朋友远程协作 | 只写 proposal 或单一 branch PR | 禁止 push main |

### 5.3 为什么不能所有人同时改代码

`data.js` 是地点、行动、技能、敌人、物品、NPC、主线的中心；`state.js` 是新开局、迁移、出行、行动、训练、战斗入口、渲染模型的中心。多个人同时改这两个文件，冲突几乎必然发生。

所以正确流程是：

1. Agent 01 先做基础 unlock infrastructure。
2. Agent 02 基于 Agent 01 的 render model 做 UI。
3. Agent 03/04 可以先写内容 proposal，等基础合并后再由 Integrator 或单独代码 Agent 接入。
4. Agent 05 等技能和地点锁稳定后，再调早期战斗体验。
5. Agent 06 全程做 QA。

---

## 6. Codex 命令工作流

下面命令按 PowerShell / Windows 友好写法。macOS/Linux 只需要把路径斜杠和命令壳稍微调整。

### 6.1 准备主仓库

```powershell
# 进入你的项目根目录
cd E:\TH比赛照片

# 确认当前状态
git status
npm run build

# 拉取最新 main
git switch main
git pull --ff-only

# 建立本轮整合分支
git switch -c staging/reforge-unlocks-v1
git push -u origin staging/reforge-unlocks-v1

# 建议创建任务和报告目录
mkdir docs\codex_tasks -Force
mkdir docs\agent_reports -Force
mkdir docs\content_proposals -Force
```

### 6.2 创建 Agent worktree

```powershell
cd E:\TH比赛照片

git worktree add ..\maws-agent-01-core -b feat/reforge-core-unlocks staging/reforge-unlocks-v1
git worktree add ..\maws-agent-02-ui -b feat/reforge-ui-locks staging/reforge-unlocks-v1
git worktree add ..\maws-agent-03-metro -b feat/reforge-metro-content staging/reforge-unlocks-v1
git worktree add ..\maws-agent-04-skills -b feat/reforge-skill-unlocks staging/reforge-unlocks-v1
git worktree add ..\maws-agent-05-combat -b feat/reforge-early-combat staging/reforge-unlocks-v1
git worktree add ..\maws-agent-06-qa -b qa/reforge-unlocks-v1 staging/reforge-unlocks-v1
```

### 6.3 单个 Agent 执行 Codex

推荐把本包里的 `codex_tasks/*.md` 复制进对应 worktree，然后执行：

```powershell
cd E:\maws-agent-01-core
npm run build

# 如果你的 Codex CLI 支持 exec：
codex exec < docs\codex_tasks\AGENT_01_CORE_UNLOCKS.md

# 如果你的 Codex 是交互模式：
codex
# 然后粘贴 docs\codex_tasks\AGENT_01_CORE_UNLOCKS.md 全文

npm run build
git diff --name-only
git status
```

如果 Codex 改了不该改的文件：

```powershell
# 示例：Agent 02 不该改 data.js/state.js
git restore maws_src\content\data.js
git restore maws_src\simulation\state.js
```

提交：

```powershell
git add maws_src\content\data.js maws_src\simulation\state.js docs\agent_reports\AGENT_01_CORE_UNLOCKS.md
git commit -m "feat: add reforge location locks and reduced starter skills"
git push -u origin feat/reforge-core-unlocks
```

### 6.4 整合分支合并

```powershell
cd E:\TH比赛照片
git switch staging/reforge-unlocks-v1
git pull --ff-only

# 先合核心，再合 UI，再合内容，再合 combat
git merge --no-ff feat/reforge-core-unlocks
npm run build

git merge --no-ff feat/reforge-ui-locks
npm run build

git merge --no-ff feat/reforge-metro-content
npm run build

git merge --no-ff feat/reforge-skill-unlocks
npm run build

git merge --no-ff feat/reforge-early-combat
npm run build

# 最后 QA
git merge --no-ff qa/reforge-unlocks-v1
npm run build
git diff --check
```

最终 PR：

```powershell
gh pr create --base main --head staging/reforge-unlocks-v1 --title "Reforge progression: locked locations, metro station, and staged skill unlocks" --body "Adds staged location unlocks, metro station, reduced starter skills, skill unlock chain, and QA notes."
```

---

## 7. 开发顺序

### Phase 0：准备与当前审计

目标：不改代码，只确认当前版本能 build。

执行：Agent 00 / QA Agent。

交付：

- `docs/agent_reports/00_current_audit.md`
- 当前可用地点列表
- 当前可用技能列表
- 当前主线节点列表
- 当前 build 结果

### Phase 1：地点锁与初始技能缩减

目标：让前期只开放少量地点，陆小闲只会少数技能。

执行：Agent 01。

必须做：

- 新增 `metro_station` 到 `LOCS` 和 `LOC_POS`。
- 新增 `LOCATION_UNLOCKS`。
- 新增 `INITIAL_SKILLS`。
- `createNewState()` 只解锁初始技能。
- `migrateSave()` 不破坏旧存档已有技能。
- `buildRenderModel()` 为地点输出 `locked / lockReason`。
- `openTravel / travel` 阻止锁定地点。

不做：

- 不做 UI 精修。
- 不改 combat 伤害公式。
- 不接大量事件。

### Phase 2：锁定地点和技能的 UI 表现

目标：玩家一眼能看懂“哪里没开放、为什么没开放、去哪学技能”。

执行：Agent 02。

必须做：

- 地图卡显示锁定状态。
- 城市 overlay marker 显示锁定状态。
- 技能页显示未学会技能的来源。
- 新增地点/技能解锁 toast 或 modal 样式。

不做：

- 不改 `data.js`。
- 不改 `state.js`。

### Phase 3：地铁站事件链

目标：地铁站成为早期城市枢纽，而不是交通按钮。

执行：Agent 03。

建议先写 proposal，再接代码。

必须做：

- 地铁站行动 3-4 个。
- Day 2 地铁见义勇为主线。
- 阿豹或短视频线索可以在地铁站初见。
- 地铁站可以解锁公园、工地或拳馆线索。

### Phase 4：技能解锁链

目标：每个核心技能都有来源，且和拳谱重铸绑定。

执行：Agent 04。

必须做：

- `unlockSkill()`。
- 行动完成后可解锁技能。
- 训练小游戏完成后可解锁技能。
- 战后复盘可解锁或推进技能。
- 技能解锁弹窗。

### Phase 5：早期战斗体验

目标：技能少也不无聊。前期的乐趣来自“看不懂、撑住、被教育、复盘”。

执行：Agent 05。

必须做：

- Day 5 公园验货适配少技能。
- Day 8 一阵风适配少技能。
- 没有 `jab/straight` 时不会软锁。
- `mystic` 作为旧招，有戏剧效果但不强。
- 战后复盘明确告诉玩家下一步去哪里学。

### Phase 6：整合 QA

目标：确保多分支合并后不坏。

执行：Agent 06 + Integrator。

必须测：

- 新开局只会 4 个技能。
- Day 1 只开放 home/store/metro_station。
- 锁定地点不能前往且显示原因。
- Day 2 地铁站事件能推进。
- 事件后 park 解锁。
- Day 9 后 boxing/physio 解锁。
- 学会 jab/straight 后技能页和战斗页都显示正确。
- 旧存档不被删技能。
- `npm run build` 通过。
- 390x844 无横向溢出。

---

## 8. 每个 Agent 的验收格式

每个 Agent 结束时写 `docs/agent_reports/<agent>.md`：

```md
# Agent XX Report

## 做了什么

## 改了哪些文件

## 没做什么

## 运行了什么验证

## 验证结果

## 风险

## 需要 Integrator 注意的冲突点
```

Integrator 最后把所有报告整合进 `docs/TASK_PLAN.md`，不要让每个 Agent 都抢着改 `TASK_PLAN.md`。

---

## 9. 本轮最容易踩坑的点

### 9.1 `data.js` 竞争冲突

地点、技能、行动、主线、NPC 都在 `data.js`。不要让三个 Agent 同时改它。

建议：

- Agent 01 先改核心结构。
- Agent 03/04 先写 content proposal。
- 等 Agent 01 合并后，再由 Integrator 或单独 Agent 接入 proposal。

### 9.2 旧存档兼容

不要在 `migrateSave()` 里强行删除旧存档技能。新开局可以少技能，旧存档要保留。

### 9.3 地点锁不能挡住主线

如果 Day 8 或 Day 9 主线需要进入锁定地点，要么主线发生在地铁站/出租屋，要么 `startMainEvent()` 支持主线临时 override。

推荐方案：Day 8 一阵风发生在地铁站或公园，不要求拳馆提前开放；Day 9 日记后再开放拳馆。

### 9.4 UI 信息密度

移动端已有底部导航和战斗技能卡压力。新增锁定原因和技能来源时，移动端要折叠，不要把按钮顶出屏幕。

### 9.5 Codex 远程朋友协作

朋友可以参与，但最好先给内容 proposal 或单文件任务。不要让朋友直接改 `state.js` 和 `data.js`，除非他单独拿一个 branch 并且你准备手动处理冲突。

---

## 10. 最终目标画面

Day 1 玩家看到：

```text
地点：出租屋 / 便利店 / 地铁站
未开放：公园、拳馆、武馆、MMA馆、散打馆、空手道道场、跆拳道社……
技能：混元一气掌、防守抱架、后撤拉开、言语降温
```

Day 10 玩家看到：

```text
地点开放：拳馆、理疗店、社区健身房
新技能：刺拳、直拳
拳谱：茂家开山拳出现新注
```

Day 24 玩家看到：

```text
地点开放：MMA、旧城区、散打馆、空手道、跆拳道
技能来源清晰，拳谱五大模块正在成型
```

这时玩家会自然感到：

> 我不是一开始就会很多招。是我把这个城市一点点打开，把茂家拳一点点练出来的。

