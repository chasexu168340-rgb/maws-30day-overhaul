# MAWS 重铸优化多 Agent 开发书包 v0.3

这份包用于《了不起的武术模拟器》当前仓库的“重铸优化计划”。

核心目标：

- 前期只开放少量地点。
- 新增可进入地点：地铁站。
- 新开局减少初始技能。
- 通过地点、NPC、事件、训练小游戏逐步解锁技能。
- 多个 Codex 窗口和远程朋友可以分工协作，尽量不互相踩文件。

## 文件说明

- `MAWS_重铸优化_多Agent工作开发书_v0.3.md`：主开发书。
- `MAWS_重铸优化_多Agent工作开发书_v0.3.docx`：Word 版开发书。
- `COMMANDS.md`：Git worktree 与 Codex 命令手册。
- `QA_CHECKLIST.md`：回归测试清单。
- `codex_tasks/`：每个 Agent 可直接复制到 Codex 的任务 prompt。
- `scripts/create_worktrees.ps1`：创建多个 worktree 的 PowerShell 脚本。
- `scripts/merge_reforge_stage.ps1`：按顺序合并分支并运行 build 的脚本。

## 推荐使用顺序

1. 先读主开发书。
2. 在主仓库创建 `staging/reforge-unlocks-v1`。
3. 用 `scripts/create_worktrees.ps1` 建 worktree。
4. 把对应 `codex_tasks/*.md` 复制进每个 worktree。
5. 每个 Agent 只做自己的 prompt，不碰禁止文件。
6. Integrator 按 `COMMANDS.md` 合并并运行 build。

## 最重要的提醒

不要让多个 Agent 同时直接修改 `data.js` 和 `state.js`。这两个文件是当前项目的中心，必须由一个核心 Agent 或 Integrator 串行处理。
