# Codex 多窗口 / 多 Agent 命令手册

这份命令手册用于《了不起的武术模拟器》重铸优化计划。目标是让你、朋友、多个 Codex 窗口都能在不同 worktree 和 branch 里工作，尽量不互相踩文件。

## 1. 创建整合分支

```powershell
cd E:\TH比赛照片

git status
npm run build

git switch main
git pull --ff-only

git switch -c staging/reforge-unlocks-v1
git push -u origin staging/reforge-unlocks-v1

mkdir docs\codex_tasks -Force
mkdir docs\agent_reports -Force
mkdir docs\content_proposals -Force
```

## 2. 创建 worktrees

```powershell
cd E:\TH比赛照片

git worktree add ..\maws-agent-01-core -b feat/reforge-core-unlocks staging/reforge-unlocks-v1
git worktree add ..\maws-agent-02-ui -b feat/reforge-ui-locks staging/reforge-unlocks-v1
git worktree add ..\maws-agent-03-metro -b feat/reforge-metro-content staging/reforge-unlocks-v1
git worktree add ..\maws-agent-04-skills -b feat/reforge-skill-unlocks staging/reforge-unlocks-v1
git worktree add ..\maws-agent-05-combat -b feat/reforge-early-combat staging/reforge-unlocks-v1
git worktree add ..\maws-agent-06-qa -b qa/reforge-unlocks-v1 staging/reforge-unlocks-v1
```

## 3. 运行某个 Agent

```powershell
cd E:\maws-agent-01-core
npm run build

# 复制本包 codex_tasks/AGENT_01_CORE_UNLOCKS.md 到当前 worktree 的 docs/codex_tasks/
# 然后运行：
codex exec < docs\codex_tasks\AGENT_01_CORE_UNLOCKS.md

# 如果你的 Codex 版本不支持 exec：
codex
# 然后粘贴 AGENT_01_CORE_UNLOCKS.md 全文

npm run build
git diff --name-only
git status
```

## 4. 提交某个 Agent 分支

```powershell
git add maws_src\content\data.js maws_src\simulation\state.js docs\agent_reports\AGENT_01_CORE_UNLOCKS.md
git commit -m "feat: add reforge location locks and reduced starter skills"
git push -u origin feat/reforge-core-unlocks
```

## 5. 如果 Codex 改了禁止文件

```powershell
# 看它改了什么
git diff --name-only

# 示例：Agent 02 不该改 data/state，恢复它们
git restore maws_src\content\data.js
git restore maws_src\simulation\state.js

npm run build
```

## 6. 整合合并顺序

```powershell
cd E:\TH比赛照片
git switch staging/reforge-unlocks-v1
git pull --ff-only

git merge --no-ff feat/reforge-core-unlocks
npm run build

git merge --no-ff feat/reforge-ui-locks
npm run build

git merge --no-ff feat/reforge-metro-content
npm run build

git merge --no-ff feat/reforge-skill-unlocks
npm run build

git merge --no-ff feat/reforge-early-combat
npm run build

git merge --no-ff qa/reforge-unlocks-v1
npm run build
git diff --check
```

## 7. 远程朋友协作方式

让朋友不要直接 push main。给他一个独立 branch：

```powershell
git clone https://github.com/chasexu168340-rgb/maws-30day-overhaul.git maws-friend-metro
cd maws-friend-metro

git fetch origin
git switch -c feat/friend-metro-content origin/staging/reforge-unlocks-v1
npm run build

# 复制 AGENT_03_METRO_CONTENT.md，运行 Codex 或手动实现
codex exec < docs\codex_tasks\AGENT_03_METRO_CONTENT.md

npm run build
git diff --name-only
git add .
git commit -m "feat: add metro station content proposal"
git push -u origin feat/friend-metro-content
```

然后朋友开 PR 到 `staging/reforge-unlocks-v1`，不要开到 `main`。

## 8. 最终验证

```powershell
npm run build
node maws_src\tools\verify_assets.mjs
git diff --check
```

浏览器 smoke 至少检查：

- 新开局只开放 home / store / metro_station。
- 初始技能只有 mystic / guard / retreat / talkdown。
- 锁定地点不能前往且显示原因。
- Day 2 地铁站事件能解锁 park。
- Day 9 后 boxing / physio 能开放。
- 学会 jab / straight 后技能页与战斗页显示正确。
- 390x844 手机端无横向溢出。
