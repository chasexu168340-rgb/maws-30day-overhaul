# AGENT 07 - Content Only / 朋友远程内容协作

这个任务适合让朋友远程帮忙，不需要直接改运行代码。

## 允许修改

- `docs/content_proposals/metro_station_events.md`
- `docs/content_proposals/skill_unlock_lines.md`
- `docs/content_proposals/locked_location_copy.md`
- `docs/agent_reports/AGENT_07_CONTENT_ONLY_FRIEND.md`

## 禁止修改

- `maws_src/**`
- `assets/**`
- `docs/TASK_PLAN.md`

## 目标

写 3 组内容 proposal：

1. 地铁站早期事件：至少 5 个。
2. 技能解锁文案：每个核心技能 1 条。
3. 锁定地点提示文案：每个锁定地点 1 条。

## 内容风格

BG3 式失败反馈，但不要油。

要求：

- 好笑，但不把角色写成纯小丑。
- 每条文案都要有机制意义。
- 父亲线不要乱开玩笑。
- 地铁站不是打怪点，而是城市和信息流入口。

## 输出格式

```md
# 地铁站事件

## metro_hero_event
触发：Day 2 主线
选项：
结果：
收益：
文案：

# 技能解锁文案

## jab
来源：拳馆 · 沙包连击
弹窗：

# 锁定地点提示

## boxing
提示：
```
