# AGENT 02 - UI Locks / 地点锁与技能来源 UI

你负责把地点锁、技能未学会来源、解锁反馈做成玩家能看懂的 UI。

## 用户特别覆盖规则

这是多 Agent 工作流。不要修改 `docs/TASK_PLAN.md`。报告写到：

`docs/agent_reports/AGENT_02_UI_LOCKS.md`

## 先读文件

- `AGENTS.md`
- `docs/CODEX_CONTEXT.md`
- `docs/FILE_MAP.md`
- `docs/TASK_PLAN.md`
- `maws_src/dom/ui.js`
- `maws_src/dom/ui.css`
- 必要时只读 `buildRenderModel()` 输出相关部分的 `state.js`

## 允许修改

- `maws_src/dom/ui.js`
- `maws_src/dom/ui.css`
- `docs/agent_reports/AGENT_02_UI_LOCKS.md`

## 禁止修改

- `maws_src/content/data.js`
- `maws_src/simulation/state.js`
- `maws_src/simulation/combat.js`
- `maws_src/assets/manifest.js`
- `docs/TASK_PLAN.md`

## 目标

1. 地图地点卡显示 locked 状态和 lockReason。
2. 城市 overlay marker 显示 locked 状态，点击 locked marker 只显示 toast，不打开 travel modal。
3. 技能页显示未学会技能的来源提示。
4. 技能槽空位显示为“未装配”，不要让四技能开局显得坏掉。
5. 新增地点/技能解锁弹窗样式或者至少 toast 样式。
6. 移动端 390x844 不横向溢出。

## UI 文案方向

锁定地点示例：

```text
拳馆 · 未开放
真正被一阵风打醒后，你才愿意听拳馆的真话。
```

未学技能示例：

```text
直拳 · 未学会
来源：拳馆 · 重靶爆点 / 梁教练纠错
```

## 验证

```powershell
npm run build
```

手动检查：

- 新开局地图可见 locked 地点。
- locked 地点不能打开 travel。
- 技能页没有因为空槽排版崩。
- 手机端 390x844 不卡按钮。

## 报告

写入 `docs/agent_reports/AGENT_02_UI_LOCKS.md`。
