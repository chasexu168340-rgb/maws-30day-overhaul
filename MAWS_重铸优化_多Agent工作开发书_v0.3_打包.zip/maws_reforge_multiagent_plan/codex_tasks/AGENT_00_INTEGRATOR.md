# AGENT 00 - Integrator / 制作整合负责人

你在《了不起的武术模拟器》重铸优化计划中担任整合负责人。

## 读取顺序

只读取：

1. `AGENTS.md`
2. `docs/CODEX_CONTEXT.md`
3. `docs/FILE_MAP.md`
4. `docs/TASK_PLAN.md`

然后根据需要读取本轮 Agent reports。

## 目标

建立并维护 `staging/reforge-unlocks-v1` 整合分支，合并各 Agent 分支，保证每次合并后项目仍可 build，并把最终结果写入 `docs/TASK_PLAN.md`。

## 允许修改

- `docs/TASK_PLAN.md`
- `docs/agent_reports/*.md`
- 必要时解决 merge conflict 涉及的文件

## 禁止修改

- 不主动改玩法、数值、战斗公式。
- 不替其他 Agent 重写功能。
- 不扫描 `assets/imagegen*/`、`test-results/`、`node_modules/`。

## 操作步骤

1. 检查当前分支和工作区状态。
2. 运行 `npm run build` 作为 baseline。
3. 合并顺序：
   - `feat/reforge-core-unlocks`
   - `feat/reforge-ui-locks`
   - `feat/reforge-metro-content`
   - `feat/reforge-skill-unlocks`
   - `feat/reforge-early-combat`
   - `qa/reforge-unlocks-v1`
4. 每合并一个分支，立刻运行 `npm run build`。
5. 如果有冲突，优先保留已通过 build 的核心逻辑；不要凭空重写。
6. 最终运行：
   - `npm run build`
   - `node maws_src/tools/verify_assets.mjs`
   - `git diff --check`
7. 更新 `docs/TASK_PLAN.md`，只保留当前任务结果、验证、风险和下一步。

## 交付

- 合并后的 staging 分支。
- `docs/TASK_PLAN.md` 当前任务总结。
- 最终验证结果。
