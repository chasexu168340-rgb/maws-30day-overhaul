# AGENT 05 - Early Combat Feel / 少技能早期战斗手感

你负责让“开局技能少”以后战斗仍然可玩，并强化 Day 5 / Day 8 的体验。

## 用户特别覆盖规则

这是多 Agent 工作流。不要修改 `docs/TASK_PLAN.md`。报告写到：

`docs/agent_reports/AGENT_05_EARLY_COMBAT.md`

## 先读文件

- `AGENTS.md`
- `docs/CODEX_CONTEXT.md`
- `docs/FILE_MAP.md`
- `docs/TASK_PLAN.md`
- `maws_src/simulation/combat.js`
- `maws_src/simulation/state.js` 中战斗入口和 finishBattle 部分
- `maws_src/content/data.js` 中技能/敌人/主线相关段落

## 允许修改

- `maws_src/simulation/combat.js`
- 必要时少量 `maws_src/simulation/state.js`
- 必要时少量 `maws_src/content/data.js`
- `docs/agent_reports/AGENT_05_EARLY_COMBAT.md`

## 禁止修改

- `maws_src/dom/ui.js`
- `maws_src/dom/ui.css`
- 资产文件
- `docs/TASK_PLAN.md`

## 目标

1. 少技能开局不会导致战斗软锁。
2. `mystic` 作为旧拳谱技能：能出手，但风险高，不稳定。
3. Day 5 公园验货可以防守/后撤/嘴遁/旧招尝试。
4. Day 8 一阵风允许玩家操作一个窗口，但结果必须服务剧情。
5. 战后复盘推荐下一步去拳馆或地铁/公园观察，不只显示普通失败。

## 不要做

- 不要整体重调伤害曲线。
- 不要让 `mystic` 变强。
- 不要新增大型战斗系统。

## 验证

```powershell
npm run build
```

检查：

- 新开局只装备 4 技能时能进入 E01 或 Day 5 战斗。
- 没有 `jab/straight` 不会卡住确认按钮。
- `mystic` 命中也不应稳定赢拳击新人。
- `guard/retreat/talkdown` 在早期有叙事价值。
