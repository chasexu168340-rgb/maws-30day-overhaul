# AGENT 03 - Metro Station Content / 地铁站内容线

你负责地铁站地点内容和早期城市事件。注意：如果 Agent 01 尚未合并，请先只写 proposal，不直接改代码。

## 用户特别覆盖规则

这是多 Agent 工作流。不要修改 `docs/TASK_PLAN.md`。报告写到：

`docs/agent_reports/AGENT_03_METRO_CONTENT.md`

## 安全模式

如果当前分支还没有 `metro_station` 或 `LOCATION_UNLOCKS`，请只创建：

`docs/content_proposals/metro_station_content.md`

不要直接修改 `data.js`。

如果已经有 `metro_station` 和地点锁基础，再允许修改：

- `maws_src/content/data.js`
- `maws_src/simulation/events.js`
- `docs/agent_reports/AGENT_03_METRO_CONTENT.md`

## 禁止修改

- `maws_src/simulation/state.js`
- `maws_src/simulation/combat.js`
- `maws_src/dom/ui.js`
- `maws_src/dom/ui.css`
- 资产文件
- `docs/TASK_PLAN.md`

## 目标

1. 地铁站有 3-4 个行动。
2. Day 2 或早期主线有“地铁见义勇为”误判胜利。
3. 地铁站可以产生：判断、街头判断、热度、误判值、短视频线索。
4. 地铁站可以解锁公园或给出拳馆线索。
5. 内容风格：好笑但现实，不要把地铁站做成打怪点。

## 推荐行动

- `metro_observe`：观察通勤人流，涨判断/街头判断。
- `metro_short_video`：刷打假短视频，涨热度/误判，降真实性或涨压力。
- `metro_commute_shadow`：站台步法小练，涨后撤/判断。
- `metro_hero_event`：一次性事件，地铁见义勇为，表层成功，底层误判。

## 推荐文案

```text
你站出来的时候，对方确实退了。
你以为是茂家拳起了作用。
系统很诚实地记下：对方主要是被你的吨位和围观群众说服了。
```

## 验证

代码模式下运行：

```powershell
npm run build
```

内容 proposal 模式下无需 build，但要写清楚：

- 新行动 id。
- 新主线/机会卡 id。
- 推荐 unlock flags。
- 推荐收益。
