# AGENT 06 - QA / 多分支回归测试

你负责回归测试和问题报告，不负责改业务代码。

## 用户特别覆盖规则

不要修改 `docs/TASK_PLAN.md`。报告写到：

`docs/agent_reports/AGENT_06_QA.md`

## 允许修改

- `docs/agent_reports/AGENT_06_QA.md`
- 必要时新增临时 QA 说明文档

## 禁止修改

- `maws_src/**`
- `assets/**`
- `docs/TASK_PLAN.md`

## 测试命令

```powershell
npm run build
node maws_src\tools\verify_assets.mjs
```

## 测试重点

- 新开局只会 4 个技能。
- Day 1 只开放 `home/store/metro_station`。
- locked 地点不能 travel。
- locked 地点显示 reason。
- 地铁站行动能执行。
- Day 2 地铁事件能推进。
- Park 解锁后可以前往。
- Day 9 后 boxing/physio 解锁。
- 训练后可以解锁 `jab/straight`。
- E01/E06/E07/E18 仍能启动。
- 少技能状态下 Day 5/Day 8 不软锁。
- 1365x768、900x700、390x844 无横向溢出。
- 保存/读档不坏。

## 报告格式

```md
# AGENT_06_QA Report

## Build

## Asset Check

## Manual Smoke

## Responsive

## Bugs Found

## Blocking Issues

## Suggested Fix Order
```
