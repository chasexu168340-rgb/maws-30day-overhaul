# AGENT 01 - Core Unlocks / 地点锁与初始技能核心

你负责重铸优化计划的基础系统：地点锁、地铁站基础数据、初始技能缩减、地点解锁状态进入 render model。

## 用户特别覆盖规则

这是多 Agent 工作流。为避免冲突，本分支不要修改 `docs/TASK_PLAN.md`。请把报告写到：

`docs/agent_reports/AGENT_01_CORE_UNLOCKS.md`

## 先读文件

- `AGENTS.md`
- `docs/CODEX_CONTEXT.md`
- `docs/FILE_MAP.md`
- `docs/TASK_PLAN.md`
- `maws_src/content/data.js`
- `maws_src/simulation/state.js`

## 允许修改

- `maws_src/content/data.js`
- `maws_src/simulation/state.js`
- `docs/agent_reports/AGENT_01_CORE_UNLOCKS.md`

## 禁止修改

- `maws_src/dom/ui.js`
- `maws_src/dom/ui.css`
- `maws_src/simulation/combat.js`
- `maws_src/assets/manifest.js`
- 任何 asset 文件
- `docs/TASK_PLAN.md`

## 目标

1. 新增 `metro_station` 地点。
2. 新增 `LOCATION_UNLOCKS`。
3. 新增 `INITIAL_SKILLS`。
4. 新开局只解锁 `mystic / guard / retreat / talkdown`。
5. 旧存档迁移不删除已有技能。
6. `buildRenderModel()` 给每个地点输出：
   - `locked`
   - `lockReason`
   - `unlockRule` 或简要 `unlockHint`
7. `openTravel` 和 `travel` 阻止前往 locked location。
8. 所有改动必须保持 `npm run build` 通过。

## 推荐实现细节

在 `data.js` 增加：

```js
export const INITIAL_SKILLS = ['mystic', 'guard', 'retreat', 'talkdown'];

export const LOCATION_UNLOCKS = {
  home: { default: true },
  store: { default: true },
  metro_station: { default: true },
  park: { flag: 'unlock_park', day: 3, reason: '先在地铁站和便利店把城市摸清楚。' },
  worksite: { flag: 'unlock_worksite', day: 4, reason: '刘胖子还没把日结活转给你。' },
  boxing: { flag: 'unlock_boxing', day: 9, reason: '真正被一阵风打醒后，你才愿意听拳馆的真话。' },
  physio: { flag: 'unlock_physio', day: 9, reason: '身体还没开始正式投诉。' },
  gym: { flag: 'unlock_gym', day: 10, reason: '先确认身体到底差在哪里。' },
  wuguan: { flag: 'unlock_wuguan', day: 13, reason: '传统拆解还没到时候。' },
  mma: { flag: 'unlock_mma', day: 16, reason: '地面课不是第一天就能理解的东西。' },
  street: { flag: 'unlock_street', day: 18, reason: '旧城区的风险还没把你点名。' },
  sanda_gym: { flag: 'unlock_sanda_gym', minReforge: 20, day: 20, reason: '拳腿摔组合需要一点基础。' },
  karate_dojo: { flag: 'unlock_karate_dojo', minReforge: 30, day: 22, reason: '先把直线和回收练明白。' },
  taekwondo_club: { flag: 'unlock_taekwondo_club', minReforge: 40, day: 24, reason: '腿法漂亮之前，先学会落地。' }
};
```

在 `state.js` 增加 helper：

```js
function isLocationUnlocked(state, locId) {}
function locationLockReason(state, locId) {}
```

`migrateSave()` 要保留旧存档技能，不要强行改成四技能。

## 验证

运行：

```powershell
npm run build
```

手动或脚本检查：

- 新开局 `Object.keys(state.unlocked)` 只有 4 个 starter skill。
- 新开局 `equipSkills` 有 4 个技能 + 2 个空槽。
- Day 1 `home/store/metro_station` unlocked。
- Day 1 `boxing/wuguan/mma/sanda_gym/karate_dojo/taekwondo_club` locked。
- 旧存档迁移保留旧技能。

## 报告

写入 `docs/agent_reports/AGENT_01_CORE_UNLOCKS.md`：

- 做了什么。
- 改了哪些文件。
- 验证结果。
- 风险。
- 后续 UI Agent 需要读取的 render model 字段。
