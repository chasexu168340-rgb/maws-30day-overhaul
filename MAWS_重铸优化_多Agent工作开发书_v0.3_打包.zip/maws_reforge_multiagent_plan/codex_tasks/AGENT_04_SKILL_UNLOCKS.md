# AGENT 04 - Skill Unlock Chain / 技能逐步解锁链

你负责把“开局技能少、通过地点/事件/训练获得技能”的养成线接起来。

## 用户特别覆盖规则

这是多 Agent 工作流。不要修改 `docs/TASK_PLAN.md`。报告写到：

`docs/agent_reports/AGENT_04_SKILL_UNLOCKS.md`

## 安全模式

如果 Agent 01 的基础 unlock 系统尚未合并，请先写：

`docs/content_proposals/skill_unlock_chain.md`

不要直接改代码。

如果基础系统已合并，允许修改：

- `maws_src/content/data.js`
- `maws_src/simulation/state.js`
- `docs/agent_reports/AGENT_04_SKILL_UNLOCKS.md`

## 禁止修改

- `maws_src/dom/ui.js`
- `maws_src/dom/ui.css`
- `maws_src/simulation/combat.js`，除非只为兼容 unlock 数据做极小改动
- 资产文件
- `docs/TASK_PLAN.md`

## 目标

1. 新开局只保留 starter skills。
2. 行动、训练小游戏、主线、战后复盘可以解锁新技能。
3. 技能解锁要能进入日志、toast 或 modal。
4. 每个技能有明确来源。
5. 旧存档不删已有技能。

## 推荐技能来源

- `dodge`：公园观察或地铁站步法小练。
- `jab`：拳馆沙包或梁教练纠错。
- `straight`：重靶爆点或梁教练纠错。
- `palm`：武馆压力测试。
- `offbalance`：近身推击训练。
- `sprawl`：MMA 防摔判断课。
- `escape`：MMA 地面脱身课。
- `dirtyescape`：旧城区观察或地铁风险事件。
- `sanda_*`：散打馆。
- `karate_*`：空手道道场。
- `tkd_*`：跆拳道社。

## 推荐 helper

```js
function unlockSkill(state, skillId, source = '') {}
function applyUnlockRewards(state, payload = {}) {}
```

支持 action/main/choice 中：

```js
unlockSkills: ['jab']
unlockLocs: ['boxing']
```

## 验证

```powershell
npm run build
```

检查：

- 新开局 4 技能。
- 完成拳馆相关行动后能学会 `jab`。
- 学会后技能页和战斗页可用。
- 旧存档不丢技能。
