# 重铸优化计划 QA Checklist

## 基础验证

- [ ] `npm run build` 通过。
- [ ] 新开局成功。
- [ ] 保存/读档成功。
- [ ] 旧存档不会被强制删技能。
- [ ] Console 无 runtime error。

## 地点锁

- [ ] Day 1 只开放 `home`、`store`、`metro_station`。
- [ ] `park` 未解锁时显示锁定原因。
- [ ] `boxing` 未解锁时不能前往。
- [ ] `wuguan`、`mma`、`sanda_gym`、`karate_dojo`、`taekwondo_club` 前期不能前往。
- [ ] 主线或事件解锁地点后，地图和城市 overlay 同步变化。
- [ ] 锁定机会卡不会直接把玩家送到未开放地点。

## 地铁站

- [ ] 地铁站出现在地点列表和城市 overlay。
- [ ] 地铁站有背景 fallback，不报资源错误。
- [ ] 地铁站行动可执行。
- [ ] Day 2 地铁见义勇为事件可触发。
- [ ] 地铁站可以产出热度/误判/判断/街头经验相关收益。

## 初始技能

- [ ] 新开局只解锁 `mystic`、`guard`、`retreat`、`talkdown`。
- [ ] 技能槽空位显示正常。
- [ ] 未学会技能在技能页显示来源。
- [ ] 未学会技能不会进入战斗技能卡。
- [ ] 旧存档已有技能保留。

## 技能解锁

- [ ] 拳馆训练可以解锁 `jab`。
- [ ] 梁教练/重靶可以解锁 `straight`。
- [ ] 武馆压力测试可以解锁 `palm` / `offbalance`。
- [ ] MMA 训练可以解锁 `sprawl` / `escape`。
- [ ] 旧城区或地铁风险事件可以解锁 `dirtyescape`。
- [ ] 新技能解锁有明显弹窗或 toast。
- [ ] 解锁后技能页、战斗页、技能槽同步更新。

## 战斗

- [ ] 少技能状态下 Day 5 公园验货不软锁。
- [ ] 少技能状态下 Day 8 一阵风不软锁。
- [ ] 没有 `jab/straight` 时玩家仍能防守、后撤、嘴遁或使用旧招。
- [ ] `mystic` 不应该强到能稳定解决早期战斗。
- [ ] 战后复盘明确推荐下一步训练地点。

## UI / 响应式

- [ ] 1365x768 无横向溢出。
- [ ] 900x700 无横向溢出。
- [ ] 390x844 无横向溢出。
- [ ] 锁定原因移动端可读，不遮挡底部导航。
- [ ] 技能来源提示移动端可读。
- [ ] 弹窗按钮不会被底部导航遮住。

## 多 Agent 合并

- [ ] 每个 Agent 有自己的 `docs/agent_reports/*.md`。
- [ ] 只有 Integrator 更新 `docs/TASK_PLAN.md`。
- [ ] 每次 merge 后运行 `npm run build`。
- [ ] 最终 staging 分支通过 `git diff --check`。
