# MAWS Codex 自动化执行方案 v0.4

## 核心答案

不能把一整份开发书塞给一个 Codex，然后期待它在上下文用完时自己开新窗口、自己分工、自己合并、自己回归测试。稳定做法是把 Codex 变成一组无状态 worker：

- 每个 worker 只负责一个小任务。
- 每个 worker 在独立 Git worktree 和独立分支里运行。
- 长上下文靠文件续命，不靠聊天上下文。
- 做不完就写 `.codex/NEXT_PROMPT.md`。
- 外层 PowerShell 脚本检测这个文件，再启动新一轮 `codex exec`。
- 完成就写 `.codex/DONE.md`。
- 所有代码变更必须经过 `npm run build`。
- 整合由 Agent 00 串行处理，避免多 Agent 同时改同一个核心文件。

## 推荐执行模式

### 安全模式

Wave 1：Agent 01 单独跑，建立地点锁和初始技能缩减。

Wave 2：Agent 02 改 UI；Agent 03/04/05 写内容 proposal；Agent 06 做 QA。

Wave 3：Agent 00 阅读 proposal，串行整合。

### 激进模式

所有 Agent 都直接改代码，各自开 PR。这个会更快，但 `data.js` 和 `state.js` 很容易冲突，不建议第一轮使用。

## 为什么这样设计

当前项目的核心文件很集中：

- `data.js`：地点、行动、技能、敌人、物品、主线。
- `state.js`：状态、存档、行动、战斗入口、主线推进。
- `ui.js/css`：DOM UI。
- `combat.js`：战斗解析。

多个 Codex 同时改 `data.js/state.js` 很容易产生冲突。所以自动化不是“让大家一起乱改”，而是“让核心 Agent 先定接口，其他 Agent 用 proposal 或独立 UI 文件推进”。

## 上下文耗尽处理

每个 Codex prompt 都要求：

1. 读最小上下文。
2. 做小步修改。
3. 如果做不完，写 `.codex/HANDOFF.md` 和 `.codex/NEXT_PROMPT.md`。
4. 外层脚本重新启动一个 Codex 进程。

这相当于自动新开窗口，但记忆来自文件。
