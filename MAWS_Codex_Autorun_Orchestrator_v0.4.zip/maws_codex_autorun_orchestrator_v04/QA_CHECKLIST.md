# QA_CHECKLIST - 自动化执行后的验收

## 必过

- [ ] `npm run build`
- [ ] 新开局成功。
- [ ] 新开局只显示 4 个初始技能：`mystic / guard / retreat / talkdown`。
- [ ] Day 1 只开放 `home / store / metro_station`。
- [ ] 未开放地点显示锁定原因。
- [ ] 未开放地点不能弹出 travel。
- [ ] 地铁站有 3 个以上行动。
- [ ] 地铁站行动能影响 `jud / heat / street / maw.misread` 中的至少一部分。
- [ ] 技能页能显示未学会技能的来源。
- [ ] 拳馆解锁后能学 `jab / straight`。
- [ ] 公园或地铁能学 `dodge`。
- [ ] MMA 解锁后能学 `sprawl / escape`。
- [ ] 保存/读档不坏。
- [ ] 老存档已有技能不被强删。
- [ ] 390x844 无横向溢出。
- [ ] 900x700 无横向溢出。
- [ ] 1365x768 无横向溢出。

## 战斗

- [ ] 低技能开局也能进入 E01。
- [ ] 没有技能队列空崩溃。
- [ ] `confirmBattle` 正常进入短窗口。
- [ ] `surrender` 正常。
- [ ] 战后复盘正常。

## 合并前检查

- [ ] 每个 Agent 都有 `docs/agent_reports/AGENT_XX.md`。
- [ ] proposal 文件已由 Integrator 处理或明确标记为后续。
- [ ] 没有 `.codex/NEXT_PROMPT.md` 未处理。
- [ ] 没有 merge conflict。
