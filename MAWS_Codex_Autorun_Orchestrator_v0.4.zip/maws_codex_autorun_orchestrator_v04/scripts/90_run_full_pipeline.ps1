param(
  [string]$RepoRoot = "E:\TH比赛照片"
)

$ErrorActionPreference = "Stop"

Set-Location $RepoRoot

Write-Host "不建议第一次直接全自动；本脚本适合在你已经验证过每个子脚本后使用。"

& ".\scripts\00_prepare_autorun.ps1" -RepoRoot $RepoRoot
& ".\scripts\10_create_worktrees.ps1" -RepoRoot $RepoRoot
& ".\scripts\20_launch_wave1_core.ps1"

Write-Host "Wave 1 已启动。请等 Agent 01 窗口完成并合并后，再手动运行 Wave 2。"
