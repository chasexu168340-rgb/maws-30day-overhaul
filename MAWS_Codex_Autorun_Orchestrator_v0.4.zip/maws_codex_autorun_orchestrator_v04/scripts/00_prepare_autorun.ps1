param(
  [string]$RepoRoot = "E:\TH比赛照片"
)

$ErrorActionPreference = "Stop"

Set-Location $RepoRoot

Write-Host "== MAWS Codex Autorun Prepare =="

if (!(Test-Path ".git")) {
  throw "当前目录不是 Git 仓库：$RepoRoot"
}

New-Item -ItemType Directory -Force -Path "docs\codex_tasks" | Out-Null
New-Item -ItemType Directory -Force -Path "docs\agent_reports" | Out-Null
New-Item -ItemType Directory -Force -Path "docs\content_proposals" | Out-Null
New-Item -ItemType Directory -Force -Path ".codex" | Out-Null

git status --short
npm run build

Write-Host "准备完成。下一步运行 scripts\10_create_worktrees.ps1"
