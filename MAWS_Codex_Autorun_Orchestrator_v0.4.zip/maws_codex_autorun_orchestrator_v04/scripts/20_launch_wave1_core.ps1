param(
  [string]$ParentDir = "E:\",
  [string]$PromptSource = "E:\TH比赛照片\docs\codex_tasks"
)

$ErrorActionPreference = "Stop"

$worktree = Join-Path $ParentDir "maws-agent-01-core"
$script = "E:\TH比赛照片\scripts\run_agent_loop.ps1"
$prompt = Join-Path $PromptSource "AGENT_01_CORE_UNLOCKS.md"

if (!(Test-Path $worktree)) { throw "缺少 worktree：$worktree" }
if (!(Test-Path $prompt)) { throw "缺少 prompt：$prompt" }

New-Item -ItemType Directory -Force -Path (Join-Path $worktree "docs\codex_tasks") | Out-Null
Copy-Item $prompt (Join-Path $worktree "docs\codex_tasks\AGENT_01_CORE_UNLOCKS.md") -Force

Start-Process powershell -ArgumentList @(
  "-NoExit",
  "-ExecutionPolicy", "Bypass",
  "-Command",
  "cd `"$worktree`"; & `"$script`" -AgentName AGENT_01_CORE_UNLOCKS -PromptFile docs\codex_tasks\AGENT_01_CORE_UNLOCKS.md -MaxRounds 4"
)
