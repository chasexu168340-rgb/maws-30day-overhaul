# COMMANDS - Codex 自动化执行命令

## 0. 前置条件

在项目根目录：

```powershell
cd E:\TH比赛照片
git status
npm run build
```

要求：

- 工作区干净，或你已经知道哪些是未提交改动。
- `npm run build` 能通过。
- Codex CLI 可用，并且支持类似 `codex exec < prompt.md` 的非交互执行。
- GitHub push 权限正常。

如果你的 Codex CLI 不支持 `exec`，可以用交互模式：

```powershell
codex
```

然后把 `prompts/AGENT_XX_*.md` 全文粘进去。交互模式不能真正无人值守，只能半自动。

## 1. 准备任务文件

把本包里的 `scripts/` 和 `prompts/` 复制到项目根目录。

```powershell
Copy-Item .\scripts E:\TH比赛照片\scripts -Recurse -Force
Copy-Item .\prompts E:\TH比赛照片\docs\codex_tasks -Recurse -Force
```

## 2. 建 staging 分支

```powershell
cd E:\TH比赛照片
git switch main
git pull --ff-only
git switch -c staging/reforge-unlocks-v1
git push -u origin staging/reforge-unlocks-v1
```

## 3. 创建 worktree

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\10_create_worktrees.ps1
```

## 4. 先跑核心 Agent

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\20_launch_wave1_core.ps1
```

完成后检查：

```powershell
cd ..\maws-agent-01-core
git status
npm run build
```

如果通过，合并：

```powershell
cd E:\TH比赛照片
git switch staging/reforge-unlocks-v1
git merge --no-ff feat/reforge-core-unlocks
npm run build
git push
```

## 5. 再跑并行 Agent

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\30_launch_wave2_parallel.ps1
```

这些 Agent 中，建议 03/04/05 默认写 proposal，不直接改核心文件：

- Agent 02：UI 锁点展示。
- Agent 03：地铁站内容 proposal。
- Agent 04：技能解锁链 proposal。
- Agent 05：早期战斗 proposal。
- Agent 06：QA。

## 6. 收集报告

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\40_collect_reports.ps1
```

## 7. 整合

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\50_merge_order.ps1
```

如果冲突，运行整合 Agent：

```powershell
cd E:\TH比赛照片
codex exec < docs\codex_tasks\AGENT_00_INTEGRATOR.md
npm run build
```

## 8. 最终检查

```powershell
npm run build
node maws_src/tools/verify_assets.mjs
git status
```

浏览器 smoke：

```powershell
npx http-server . -p 8137
```

打开：

```text
http://127.0.0.1:8137/maws_30day_overhaul_v3.html
```
