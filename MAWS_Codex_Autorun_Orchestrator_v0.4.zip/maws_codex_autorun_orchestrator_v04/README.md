# MAWS Codex 自动执行器 v0.4

目标：把《了不起的武术模拟器》重铸优化任务拆成多个 Codex worker，通过 Git worktree + 分支 + checkpoint 文件来并行推进。

重要边界：

1. Codex 交互窗口本身不能被稳定要求“上下文用完自动新开窗口”。
2. 稳定方案是：外层脚本每次启动一个新的 Codex exec 进程；每个进程只做小任务；做不完就写 `.codex/NEXT_PROMPT.md`，脚本再用这个文件启动下一轮。
3. 所有长期记忆必须落文件：`docs/TASK_PLAN.md`、`docs/agent_reports/*.md`、`.codex/HANDOFF.md`、`.codex/NEXT_PROMPT.md`。
4. 不要让多个 Agent 同时直接改同一个核心文件。推荐“核心 Agent 先跑，内容 Agent 写 proposal，整合 Agent 串行落代码”。

推荐运行入口：

```powershell
cd E:\TH比赛照片
powershell -ExecutionPolicy Bypass -File .\scripts\00_prepare_autorun.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\10_create_worktrees.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\20_launch_wave1_core.ps1
```

Wave 1 合并后再运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\30_launch_wave2_parallel.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\40_collect_reports.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\50_merge_order.ps1
```

你也可以用 `90_run_full_pipeline.ps1` 尝试一口气执行，但不建议第一次就全自动，因为任何 merge conflict、Codex approval、build error 都应该停下来人工看一眼。
