param(
  [string]$RepoRoot = "E:\TH比赛照片",
  [string]$PackRoot = "."
)

$ErrorActionPreference = "Stop"
Set-Location $RepoRoot

New-Item -ItemType Directory -Force -Path "docs\codex_agent_profiles" | Out-Null
New-Item -ItemType Directory -Force -Path "docs\codex_tasks" | Out-Null

Copy-Item "$PackRoot\docs\codex_agent_profiles\*.md" "docs\codex_agent_profiles" -Force
Copy-Item "$PackRoot\docs\codex_tasks\*.md" "docs\codex_tasks" -Force
Copy-Item "$PackRoot\SKILL_ROUTING.md" "docs\SKILL_ROUTING.md" -Force
Copy-Item "$PackRoot\NEXT_WAVE_PLAN.md" "docs\NEXT_WAVE_PLAN.md" -Force

git status --short
Write-Host "Agent profiles copied. Review, then commit."
