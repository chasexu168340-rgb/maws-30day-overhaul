# MAWS Broad Agent Skill Routing v0.5

这套文件用于把当前一次性小任务 Agent，升级成长期可复用的“制作部门制”Agent。

核心目标：
- Agent 按制作大类命名，不再按一次性编号命名。
- 每个 Agent 都绑定主 Skill 和辅助 Skill。
- Skill 缺失时不停止任务，只在报告里记录 missing skill。
- 适配当前 Phaser + DOM 架构。
